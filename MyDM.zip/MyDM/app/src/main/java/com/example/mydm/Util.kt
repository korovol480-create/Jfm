package com.example.mydm

fun fmtBytes(b: Long): String {
    if (b < 1024) return "$b B"
    val u = arrayOf("KB", "MB", "GB", "TB")
    var v = b / 1024.0
    var i = 0
    while (v >= 1024 && i < 3) { v /= 1024; i++ }
    return "%.1f %s".format(v, u[i])
}
fun fmtSpeed(b: Long) = fmtBytes(maxOf(b, 0)) + "/s"
fun String.isUrl() = matches(Regex("^https?://\\S+$"))
